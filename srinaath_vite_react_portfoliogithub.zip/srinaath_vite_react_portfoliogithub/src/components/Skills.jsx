import React from "react";
import { FaHtml5, FaCss3Alt, FaJsSquare, FaPython, FaJava, FaReact, FaNodeJs, FaDatabase } from "react-icons/fa";
import { SiMysql, SiPowerbi, SiTableau, SiGit } from "react-icons/si";

const skillCategories = [
  {
    category: "Programming Languages",
    skills: [
      { name: "HTML", icon: <FaHtml5 color="#E34F26" /> },
      { name: "CSS", icon: <FaCss3Alt color="#1572B6" /> },
      { name: "JavaScript", icon: <FaJsSquare color="#F7DF1E" /> },
      { name: "Python", icon: <FaPython color="#3776AB" /> },
      { name: "Java", icon: <FaJava color="#007396" /> },
      { name: "SQL", icon: <FaDatabase color="#F29111" /> },
    ],
  },
  {
    category: "Frontend Frameworks",
    skills: [{ name: "ReactJS", icon: <FaReact color="#61DAFB" /> }],
  },
  {
    category: "Backend & Databases",
    skills: [
      { name: "MySQL", icon: <SiMysql color="#4479A1" /> },
    ],
  },
  {
    category: "Data Visualization Tools",
    skills: [
      { name: "Power BI", icon: <SiPowerbi color="#F2C811" /> },
      { name: "Tableau", icon: <SiTableau color="#E97627" /> },
    ],
  },
  {
    category: "Tools & Version Control",
    skills: [{ name: "Git", icon: <SiGit color="#F05032" /> }],
  }
];

export default function Skills() {
  return (
    <section style={{ padding: "80px 20px", maxWidth: "1200px", margin: "0 auto" }}>
      <h2 style={{ textAlign: "center", marginBottom: "50px", color: "#1a73e8" }}>Skills</h2>
      {skillCategories.map((cat, idx) => (
        <div key={idx} style={{ marginBottom: "50px" }}>
          <h3 style={{ marginBottom: "25px", textAlign: "center", color: "#333" }}>{cat.category}</h3>
          <div style={{ display: "flex", flexWrap: "wrap", justifyContent: "center", gap: "20px" }}>
            {cat.skills.map((skill, i) => (
              <div key={i} style={{
                width: "140px",
                height: "140px",
                display: "flex",
                flexDirection: "column",
                alignItems: "center",
                justifyContent: "center",
                backgroundColor: "#fff",
                borderRadius: "15px",
                boxShadow: "0 6px 15px rgba(0,0,0,0.08)",
                transition: "transform 0.3s, box-shadow 0.3s",
              }}>
                <div style={{ fontSize: "40px", marginBottom: "10px" }}>{skill.icon}</div>
                <p style={{ fontWeight: "600", color: "#333" }}>{skill.name}</p>
              </div>
            ))}
          </div>
        </div>
      ))}
    </section>
  );
}
