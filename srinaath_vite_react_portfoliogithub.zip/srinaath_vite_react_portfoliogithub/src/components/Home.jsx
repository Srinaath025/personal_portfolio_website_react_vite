import React from "react";
import profile from "../assets/profile.jpg";
import { FaDownload } from "react-icons/fa";

export default function Home() {
  return (
    <section id="home">
      <img src={profile} alt="Srinath Profile" />
      <h1>Srinaath P K</h1>
      <p>AI & Data Science Enthusiast</p>
      <a href="/Srinath_Resume.pdf" download>
        <FaDownload /> Download Resume
      </a>
    </section>
  );
}
