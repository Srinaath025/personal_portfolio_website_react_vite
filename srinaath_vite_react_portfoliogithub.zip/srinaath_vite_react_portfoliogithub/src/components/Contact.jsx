import React, { useState } from 'react';
import emailjs from 'emailjs-com';

export default function Contact() {
  const [form, setForm] = useState({ name: "", email: "", message: "" });

  const handleChange = e => setForm({ ...form, [e.target.name]: e.target.value });

  const handleSubmit = e => {
    e.preventDefault();
    emailjs.send('service_id', 'template_id', form, 'user_id')
      .then(() => alert("Message sent!"))
      .catch(err => alert("Error: " + err));
    setForm({ name: "", email: "", message: "" });
  };

  return (
    <section style={{ padding: "80px 20px", maxWidth: "600px", margin: "0 auto" }}>
      <h2 style={{ textAlign: "center", marginBottom: "40px", color: "#1a73e8" }}>Contact Me</h2>
      <form onSubmit={handleSubmit} style={{ display: "flex", flexDirection: "column", gap: "15px" }}>
        <input name="name" value={form.name} onChange={handleChange} placeholder="Your Name" required style={{ padding: "12px", borderRadius: "8px", border: "1px solid #ccc" }}/>
        <input name="email" type="email" value={form.email} onChange={handleChange} placeholder="Your Email" required style={{ padding: "12px", borderRadius: "8px", border: "1px solid #ccc" }}/>
        <textarea name="message" value={form.message} onChange={handleChange} placeholder="Your Message" rows={5} required style={{ padding: "12px", borderRadius: "8px", border: "1px solid #ccc" }}/>
        <button type="submit">Send</button>
      </form>
      <p style={{ textAlign: "center", marginTop: "20px" }}>
        Connect with me: 
        <a href="https://linkedin.com/in/srinaathpk" target="_blank" rel="noopener noreferrer"> LinkedIn</a> | 
        <a href="https://github.com/Srinaath025" target="_blank" rel="noopener noreferrer"> GitHub</a>
      </p>
    </section>
  );
}
