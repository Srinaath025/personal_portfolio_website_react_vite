import React from "react";

export default function About() {
  return (
    <section id="about">
      <h2>About Me</h2>
      <p>
       Motivated individual seeking a challenging position in the field of Artificial Intelligence and Data Science, with a
strong passion for solving real-world problems through intelligent systems and data-driven insights. Committed to
contributing meaningfully to organizational goals while consistently enhancing analytical thinking, innovation, and
technical expertise in emerging AI technologies.
      </p>
      
    </section>
  );
}
